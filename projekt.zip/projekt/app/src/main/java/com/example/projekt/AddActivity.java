package com.example.projekt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AddActivity extends AppCompatActivity {

    EditText mTitle, mDesc, mDate;
    Button mSaveButton, mListButton;
    String currentDate;

    ProgressDialog pd;

    FirebaseFirestore db;

    String pId, pTitle, pDescr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_list);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Új szolgáltatás hozzáadása");

        mTitle = findViewById(R.id.serviceTitle);
        mDesc = findViewById(R.id.serviceDesc);
        mSaveButton = findViewById(R.id.saveButton);
        mListButton = findViewById(R.id.listButton);
        Calendar calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance().format(calendar.getTime());

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            actionBar.setTitle("Szolgáltatás frissítése");
            mSaveButton.setText("Frissít");

            pId = bundle.getString("pId");
            pTitle = bundle.getString("pTitle");
            pDescr = bundle.getString("pDescr");

            mTitle.setText(pTitle);
            mDesc.setText(pDescr);
        } else {
            actionBar.setTitle("Új szolgáltatás hozzáadása");
            mSaveButton.setText("Mentés");
        }

        pd = new ProgressDialog(this);

        db = FirebaseFirestore.getInstance();

        mSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = getIntent().getExtras();
                if (bundle != null) {
                    String id = pId;
                    String title = mTitle.getText().toString().trim();
                    String description = mDesc.getText().toString().trim();

                    if (title.isEmpty()) {
                        Toast.makeText(AddActivity.this, "A szolgáltatás neve nem lehet üres!", Toast.LENGTH_LONG).show();
                    } else if (description.isEmpty()) {
                        Toast.makeText(AddActivity.this, "A szolgáltatás leírása nem lehet üres!", Toast.LENGTH_LONG).show();
                    } else {
                        updateData(id, title, description, currentDate);
                    }
                } else {
                    String title = mTitle.getText().toString().trim();
                    String description = mDesc.getText().toString().trim();

                    if (title.isEmpty()) {
                        Toast.makeText(AddActivity.this, "A szolgáltatás neve nem lehet üres!", Toast.LENGTH_LONG).show();
                    } else if (description.isEmpty()) {
                        Toast.makeText(AddActivity.this, "A szolgáltatás leírása nem lehet üres!", Toast.LENGTH_LONG).show();
                    } else {
                        uploadData(title, description, currentDate);
                        mTitle.setText("");
                        mDesc.setText("");
                    }
                }
            }
        });

        mListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddActivity.this, ListActivity.class));
                finish();
            }
        });
    }

    private void updateData(String id, String title, String description, String currentDate) {
        pd.setTitle("Updating data to Firestore");
        pd.show();
        db.collection("Services").document(id)
                .update("title", title,  "description", description, "startDate", currentDate)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        pd.dismiss();
                        Toast.makeText(AddActivity.this, "Frissítve", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void uploadData(String title, String description, String currentDate) {
        pd.setTitle("Adding data to Firestore");
        pd.show();
        String id = UUID.randomUUID().toString();

        Map<String, Object> doc = new HashMap<>();
        doc.put("id", id);
        doc.put("title", title);
        doc.put("description", description);
        doc.put("startDate", currentDate);

        db.collection("Services").document(id).set(doc)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        pd.dismiss();
                        Toast.makeText(AddActivity.this, "Feltöltve", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}