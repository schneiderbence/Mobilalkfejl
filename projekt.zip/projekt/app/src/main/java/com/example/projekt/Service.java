package com.example.projekt;


import java.util.Date;
import java.util.List;

public class Service {

    private String id;
    private String category;
    private String description;
    private String name;
    private String phoneNumber;
    private Date cancellationDate;
    private Date completionDate;
    private Date orderDate;
    private String startDate;
    private Date expectedCompletionDate;
    private String cancellationReason;
    private String externalId;
    private String href;
    private String notificationContact;
    private String priority;
    private List note;
    private List externalReference;
    private List relatedParty;
    private List serviceOrderItem;


    public Service() {
    }

    public Service(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public Service(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Service(String id, String name, String description, String startDate) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startDate = startDate;
    }

    /*public Service(String category, String description, String name, String phoneNumber) {
        this.category = category;
        this.description = description;
        this.name = name;
        this.phoneNumber = phoneNumber;
    }
*/
    public Service(String id, String category, String description, String name, String phoneNumber, Date cancellationDate, Date completionDate, Date orderDate, String startDate, Date expectedCompletionDate, String cancellationReason, String externalId, String href, String notificationContact, String priority, List note, List externalReference, List relatedParty, List serviceOrderItem) {
        this.id = id;
        this.category = category;
        this.description = description;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.cancellationDate = cancellationDate;
        this.completionDate = completionDate;
        this.orderDate = orderDate;
        this.startDate = startDate;
        this.expectedCompletionDate = expectedCompletionDate;
        this.cancellationReason = cancellationReason;
        this.externalId = externalId;
        this.href = href;
        this.notificationContact = notificationContact;
        this.priority = priority;
        this.note = note;
        this.externalReference = externalReference;
        this.relatedParty = relatedParty;
        this.serviceOrderItem = serviceOrderItem;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Date getCancellationDate() {
        return cancellationDate;
    }

    public void setCancellationDate(Date cancellationDate) {
        this.cancellationDate = cancellationDate;
    }

    public Date getCompletionDate() {
        return completionDate;
    }

    public void setCompletionDate(Date completionDate) {
        this.completionDate = completionDate;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Date getExpectedCompletionDate() {
        return expectedCompletionDate;
    }

    public void setExpectedCompletionDate(Date expectedCompletionDate) {
        this.expectedCompletionDate = expectedCompletionDate;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getNotificationContact() {
        return notificationContact;
    }

    public void setNotificationContact(String notificationContact) {
        this.notificationContact = notificationContact;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public List getNote() {
        return note;
    }

    public void setNote(List note) {
        this.note = note;
    }

    public List getExternalReference() {
        return externalReference;
    }

    public void setExternalReference(List externalReference) {
        this.externalReference = externalReference;
    }

    public List getRelatedParty() {
        return relatedParty;
    }

    public void setRelatedParty(List relatedParty) {
        this.relatedParty = relatedParty;
    }

    public List getServiceOrderItem() {
        return serviceOrderItem;
    }

    public void setServiceOrderItem(List serviceOrderItem) {
        this.serviceOrderItem = serviceOrderItem;
    }
}
