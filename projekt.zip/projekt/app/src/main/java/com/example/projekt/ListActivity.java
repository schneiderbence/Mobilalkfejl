package com.example.projekt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;


public class ListActivity extends AppCompatActivity {

    private static final String LOG_TAG = ListActivity.class.getName();
    private List<Service> serviceList;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private FloatingActionButton mAddBtn;
    private Button cartButton;
    private boolean orderBy = true;
    private NotificationHelper mNotificationHelper;
    private AlarmManager mAlarmManager;


    CustomAdapter adapter;
    FirebaseFirestore db;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Szolgáltatások");


        recyclerView = findViewById(R.id.recycler_view);
        mAddBtn = findViewById(R.id.addBtn);
        cartButton = findViewById(R.id.add_to_cart);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        db = FirebaseFirestore.getInstance();

        serviceList = new ArrayList<>();
        pd = new ProgressDialog(this);


        showData();
        mNotificationHelper = new NotificationHelper(this);
        mAlarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        setAlarmManager();

        mAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListActivity.this, AddActivity.class));
                finish();
            }
        });


    }


    private void showData() {
        pd.setTitle("Loading data");
        pd.show();
        adapter = new CustomAdapter(ListActivity.this, serviceList, this);
        db.collection("Services").get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        serviceList.clear();
                        pd.dismiss();

                        for(DocumentSnapshot doc : task.getResult()) {
                            Service service = new Service(doc.getString("id"),
                            doc.getString("title"),
                            doc.getString("description"),
                            doc.getString("startDate"));
                            serviceList.add(service);
                        }
                        recyclerView.setAdapter(adapter);

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(ListActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });
    }

    public void deleteData (int index) {
        pd.setTitle("Deleting data");
        pd.show();
        db.collection("Services").document(serviceList.get(index).getId())
                .delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(ListActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                showData();
            }
        })
        .addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(ListActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.shop_list_menu, menu);

        MenuItem item = menu.findItem(R.id.search_bar);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                if (s.isEmpty()) {
                    showData();
                } else {
                    adapter.getFilter().filter(s);
                }
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    private void dataOrderBy () {
        orderBy = !orderBy;
        if (orderBy) {
            db.collection("Services").orderBy("title", Query.Direction.DESCENDING)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            serviceList.clear();
                            pd.dismiss();

                            for (DocumentSnapshot doc : task.getResult()) {
                                Service service = new Service(doc.getString("id"),
                                        doc.getString("title"),
                                        doc.getString("description"));
                                serviceList.add(service);
                            }
                            //adapter = new CustomAdapter(ListActivity.this, serviceList);

                            recyclerView.setAdapter(adapter);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            pd.dismiss();
                            Toast.makeText(ListActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });
        } else {
            db.collection("Services").orderBy("title", Query.Direction.ASCENDING)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            serviceList.clear();
                            pd.dismiss();

                            for (DocumentSnapshot doc : task.getResult()) {
                                Service service = new Service(doc.getString("id"),
                                        doc.getString("title"),
                                        doc.getString("description"));
                                serviceList.add(service);
                            }
                            //adapter = new CustomAdapter(ListActivity.this, serviceList);

                            recyclerView.setAdapter(adapter);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            pd.dismiss();
                            Toast.makeText(ListActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });

        }

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.log_out_button:
                Log.d(LOG_TAG, "Logout clicked!");
                FirebaseAuth.getInstance().signOut();
                finish();
                return true;
            case R.id.cart:
                Log.d(LOG_TAG, "Cart clicked!");
                return true;
            case R.id.orderBy:
                adapter = new CustomAdapter(ListActivity.this, serviceList, this);
                recyclerView.setAdapter(adapter);
                if (orderBy) {
                    dataOrderBy();
                } else {
                    dataOrderBy();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setAlarmManager() {
        long repeatInterval = 10 * 1000;//AlarmManager.INTERVAL_FIFTEEN_MINUTES;
        long triggerTime = SystemClock.elapsedRealtime() + repeatInterval;
        Intent intent = new Intent(this, AlarmReciever.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        mAlarmManager.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                triggerTime,
                repeatInterval,
                pendingIntent);

        //mAlarmManager.cancel(pendingIntent);
    }
}