package com.example.projekt;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<ViewHolder> implements Filterable {

    ListActivity listActivity;
    List<Service> serviceList;
    private Context mContext;
    private int lastPosition = -1;

    public CustomAdapter(ListActivity listActivity, List<Service> serviceList, Context mContext) {
        this.listActivity = listActivity;
        this.serviceList = serviceList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.model_layout, parent, false);

        ViewHolder viewHolder = new ViewHolder(itemView);

        viewHolder.setOnClickListener(new ViewHolder.ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String title = serviceList.get(position).getName();
                String descr = serviceList.get(position).getDescription();
                Toast.makeText(listActivity, title + "\n" + descr, Toast.LENGTH_SHORT).show();

            }



            @Override
            public void onItemLongClick(View view, int position) {

                AlertDialog.Builder builder = new AlertDialog.Builder(listActivity);
                String[] options = {"Frissítés", "Törlés"};
                builder.setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                                String id = serviceList.get(position).getId();
                                String title = serviceList.get(position).getName();
                                String descr = serviceList.get(position).getDescription();

                                Intent intent = new Intent(listActivity, AddActivity.class);
                                intent.putExtra("pId", id);
                                intent.putExtra("pTitle", title);
                                intent.putExtra("pDescr", descr);
                                listActivity.startActivity(intent);
                        }
                        if (which == 1) {
                            listActivity.deleteData(position);
                        }
                    }
                }).create().show();
            }
        });

        return viewHolder;
    }

    @Override
    public Filter getFilter() {
        return serviceFilter;
    }

    private Filter serviceFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Service> filteredList = new ArrayList<>();
            FilterResults results = new FilterResults();

            if(charSequence == null || charSequence.length() == 0) {
                results.count = serviceList.size();
                results.values = serviceList;
            } else {
                String filterPattern = charSequence.toString().toLowerCase().trim();
                for(Service item : serviceList) {
                    if(item.getName().toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                }
                results.count = filteredList.size();
                results.values = filteredList;
            }

            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            serviceList = (ArrayList)filterResults.values;
            notifyDataSetChanged();
        }
    };

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.mTitle.setText(serviceList.get(position).getName());
        holder.mDesc.setText(serviceList.get(position).getDescription());
        holder.mDate.setText(serviceList.get(position).getStartDate());
    }

    @Override
    public int getItemCount() {
        return serviceList.size();
    }

}
