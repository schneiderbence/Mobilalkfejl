package com.example.projekt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReciever extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        new NotificationHelper(context).send("Itt az idő hogy vásárolj egy szolgáltatást!");
    }
}
